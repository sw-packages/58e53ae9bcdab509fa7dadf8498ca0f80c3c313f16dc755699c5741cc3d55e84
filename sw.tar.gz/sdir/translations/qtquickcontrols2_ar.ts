<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ar">
<context>
    <name>QQuickPlatformDialog</name>
    <message>
        <source>Dialog is an abstract base class</source>
        <translation>إنّ Dialog صنف أساسيّ مجرّد</translation>
    </message>
    <message>
        <source>Cannot create an instance of StandardButton</source>
        <translation>لا يمكن إنشاء سيرورة من StandardButton</translation>
    </message>
</context>
<context>
    <name>QtQuickControls2MaterialStylePlugin</name>
    <message>
        <source>Material is an attached property</source>
        <translation>إنّ Material صفة مرفقة</translation>
    </message>
</context>
<context>
    <name>QtQuickControls2UniversalStylePlugin</name>
    <message>
        <source>Universal is an attached property</source>
        <translation>إنّ Universal صفة مرفقة</translation>
    </message>
</context>
</TS>
